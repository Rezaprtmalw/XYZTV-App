package com.xyz.iptv
data class Channel(val name: String, val url: String)
